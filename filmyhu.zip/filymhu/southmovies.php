<?php
include "includes/hydpkbose_bole_kahan_dbconnect.php";
$sql="select * from movies where category='south' order by id DESC";
$res=mysqli_query($conn,$sql);
$row=mysqli_num_rows($res);
$result_per_page=40;
if(!isset($_GET['page']))
{
	$page=1;
	
}
else
{
	$page=$_GET['page'];
	
}

$this_page_first=($page-1)*$result_per_page;
$no_of_pages=ceil($row/$result_per_page);
$sqlite="select * from movies where category='south' LIMIT ".$this_page_first.','.$result_per_page;
$result=mysqli_query($conn,$sqlite);
$rows=mysqli_num_rows($result);
if($rows>0)
{
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>filmyhu south movies download,filmyhu south hindi dubbed,Latest south indian Movies download,2018 south hindi dubbed movies download,Download south indian hindi movies free,Hindi movies download,latest south hindi movie download,latest telugu hindi movies download,latest tamil hindi movies download,hd south hindi movie download</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" >
<meta name="keywords" content="latest south  movies online free,Download Latest south indian movies,filmyhu south indian telugu or tamil movies download,south hindi dubbed 720p movies download hd,latest tamil hindi dubbed movies download,latest telugu hindi dubbed movies download,download latest south movie in hindi,south hindi dubbed movies download online,online latest tamil,telgu hindi dubbed movie free" >
<meta name="description" content="Filmyhu is biggest online movie downloading website.Watch and download latest telgu or tamil movies online free,Download Latest south indian hindi dubbed movies,filmyhu south movies download,south dubbed 720p movies download hd,latest hindi dubbed south movies movies download,download latest telugu movie in hindi,download latest tamil movie in hindi,south hindi dubbed movies download online,online latest south indian hindi dubbed movie free">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/main.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="css/contactstyle.css" type="text/css" media="all" />
<link rel="stylesheet" href="css/faqstyle.css" type="text/css" media="all" />
<link href="css/single.css" rel='stylesheet' type='text/css' />
<link href="css/medile.css" rel='stylesheet' type='text/css' />
<!-- banner-slider -->
<link href="css/jquery.slidey.min.css" rel="stylesheet">
<!-- //banner-slider -->
<!-- pop-up -->
<link href="css/popuo-box.css" rel="stylesheet" type="text/css" media="all" />
<!-- //pop-up -->
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font-awesome.min.css" />
<!-- //font-awesome icons -->
<!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- //js -->
<!-- banner-bottom-plugin -->
<link href="css/owl.carousel.css" rel="stylesheet" type="text/css" media="all">
<script src="js/owl.carousel.js"></script>
<script>
	$(document).ready(function() { 
		$("#owl-demo").owlCarousel({
	 
		  autoPlay: 3000, //Set AutoPlay to 3 seconds
	 
		  items : 5,
		  itemsDesktop : [640,4],
		  itemsDesktopSmall : [414,3]
	 
		});
	 
	}); 
</script> 
<!-- //banner-bottom-plugin -->
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700italic,700,400italic,300italic,300' rel='stylesheet' type='text/css'>
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>

<!-- start-smoth-scrolling -->
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-97538538-5"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-97538538-5');
</script>
<!-- Hotjar Tracking Code for https://www.filmyurl.com -->
<script>
    (function(h,o,t,j,a,r){
        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
        h._hjSettings={hjid:736074,hjsv:6};
        a=o.getElementsByTagName('head')[0];
        r=o.createElement('script');r.async=1;
        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
        a.appendChild(r);
    })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
</script>
</head>
	
<body>
   <!-- header -->
	<div class="header">
		<div class="container">
			<div class="w3layouts_logo" >
				<a href="index.php"><h1>FilmyHu</h1></a>
			</div>
			<div class="w3_search">
				<form action="search.php" method="GET">
					<input type="text" name="q" placeholder="Search Movies">
					<input type="submit" value="search">
				</form>
			</div>
					<div class="clearfix"> </div>
		</div>
	</div>
<!-- //header -->
	<div class="movies_nav">
		<div class="container">
			<nav class="navbar navbar-default">
				<div class="navbar-header navbar-left">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
					<nav>
						<ul class="nav navbar-nav">
							<li class="active"><a href="index.php">Home</a></li>
							<li><a href="https://www.filmyurl.com/latest-movies.php">Latest Movies</a></li>
							<li><a href="https://www.filmyurl.com/bollywood.php">Bollywood</a></li>
							<li><a href="https://www.filmyurl.com/hollywood.php">Hollywood</a></li>
							<li><a href="https://www.filmyurl.com/hindidubbed.php">Hindi Dubbed</a></li>
							<li><a href="https://www.filmyurl.com/southmovies.php">South Movies</a></li>
							<li><a href="https://www.filmyurl.com/privacy.php">Privacy Policy</a></li>
							</ul>	
					</nav>
				</div>
			</nav>	
		</div>
	</div>
<div class="general_social_icons">
	<nav class="social">
		<ul>
		<!--<li class="w3_whatssapp"><a href="whatsapp://send?text=https://filmyurl.com/" data-action="share/whatsapp/share"><i class="fa fa-whatsapp"></i></a></li>-->
		<li class="w3_facebook"><a href="https://www.facebook.com/filmyhu/">Facebook <i class="fa fa-facebook"></i></a></li>
			</ul>
  </nav>
</div>
<br>
<br>

		<h4 class="latest-text w3_latest_text">South Movies</h4>
<div class="container">
                    <div class="main-content">
                       
                        <div class="tab-content">
                            <div id="movie-featured" class="movies-list movies-list-full tab-pane in fade active">
									<?php
									   while($x6=mysqli_fetch_assoc($result))
									  {
		                              ?>
                                    <div class="ml-item">
                                        <a href="post.php?id=<?php echo $x6['id']; ?>" title="<?php echo $x6['title']; ?>" class="ml-mask jt">
                                            <img src="<?php echo $x6['image']; ?>" alt="<?php echo $x6['title']; ?>" class="lazy thumb mli-thumb">
                                            <span class="mli-info">
                                                <h2 style="background-color:black; color:white">
                                                <?php echo $x6['title']; ?>
                                                </h2>
                                            </span>
                                        </a>
                                    </div>    
									<?php
									}
									}
									?>		
                                    
                            </div>
                        </div>
                    </div>


</div>
<nav class="example">
 <ul class="pagination">
<?php
for($page=1;$page<=$no_of_pages;$page++)
{
?>
<li class="page-item"><?php echo '<a href="southmovies.php?page='.$page.'">'.$page.'</a>'; ?></li>
<?php
}
?>
 </ul>
</nav>
<!-------------------------------------------------------------------Movies List Finished---------------------------------------------------------------------->

<?php
include "footer.php";
?>
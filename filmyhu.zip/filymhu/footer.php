<!-- footer -->
	<div class="footer">
		<div class="container">
			<div class="w3ls_footer_grid">
			<div>
			<h2 style="color:white; text-align:center;"><span style="font-size:35px">FILMYHU</span>-<span style="font-size:25px">World's Biggest Online Streaming Website</span>
			</h2>
			</div>
				
				<div class="clearfix"> </div>
			</div>
			
				
			<div class="col-md-5 w3ls_footer_grid1_left">
				<p>&copy; 2017 FilmyHu. All rights not reserved | Design by <a href="https://filmyurl.com">FilmyHu</a></p>
			</div>
			<div class="col-md-7 w3ls_footer_grid1_right">
				<ul>
				<li>
						<a href="https://www.filmyhusongs.com" target="_blank">Download Latest MP3 songs</a>
					</li>
					
					<li>
						<a href="https://www.filmyurl.com">Home</a>
					</li>
					
					<li>
						<a href="https://www.filmyurl.com/bollywood.php">Bollywood</a>
					</li>
					<li>
						<a href="https://www.filmyurl.com/hollywood.php">Hollywood</a>
					</li>
					<li>
						<a href="https://www.filmyurl.com/hindidubbed.php">Hindi Dubbed</a>
					</li>
					<li>
						<a href="https://www.filmyurl.com/southmovies.php">South Movies</a>
					</li>
				</ul>
			</div>
		
			<div class="clearfix"> </div>
		</div>
		<p><!-------------------------------------just for space--------------------------></p>
		
		<p><!-------------------------------------just for space--------------------------></p>
		
	</div>
<!-- //footer -->
<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>
<script>
$(document).ready(function(){
    $(".dropdown").hover(            
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideDown("fast");
            $(this).toggleClass('open');        
        },
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideUp("fast");
            $(this).toggleClass('open');       
        }
    );
});
</script>
<!-- //Bootstrap Core JavaScript -->
<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/
								
			$().UItoTop({ easingType: 'easeOutQuart' });
								
			});
	</script>
<!-- //here ends scrolling icon -->
<!-------------------mobile site widget--------------->
<div id="M284834ScriptRootC183991">
        <script>
                (function(){
            var D=new Date(),d=document,b='body',ce='createElement',ac='appendChild',st='style',ds='display',n='none',gi='getElementById';
            var i=d[ce]('iframe');i[st][ds]=n;d[gi]("M284834ScriptRootC183991")[ac](i);try{var iw=i.contentWindow.document;iw.open();iw.writeln("<ht"+"ml><bo"+"dy></bo"+"dy></ht"+"ml>");iw.close();var c=iw[b];}
            catch(e){var iw=d;var c=d[gi]("M284834ScriptRootC183991");}var dv=iw[ce]('div');dv.id="MG_ID";dv[st][ds]=n;dv.innerHTML=183991;c[ac](dv);
            var s=iw[ce]('script');s.async='async';s.defer='defer';s.charset='utf-8';s.src="//jsc.mgid.com/f/i/filmyurl.com.183991.js?t="+D.getYear()+D.getMonth()+D.getDate()+D.getHours();c[ac](s);})();
    </script>
</div>
<!---------------------Exit time popup------------------>
<div id="M284834ScriptRootC183992">
        <div id="M284834PreloadC183992">
        Loading...
    </div>
        <script>
                (function(){
            var D=new Date(),d=document,b='body',ce='createElement',ac='appendChild',st='style',ds='display',n='none',gi='getElementById';
            var i=d[ce]('iframe');i[st][ds]=n;d[gi]("M284834ScriptRootC183992")[ac](i);try{var iw=i.contentWindow.document;iw.open();iw.writeln("<ht"+"ml><bo"+"dy></bo"+"dy></ht"+"ml>");iw.close();var c=iw[b];}
            catch(e){var iw=d;var c=d[gi]("M284834ScriptRootC183992");}var dv=iw[ce]('div');dv.id="MG_ID";dv[st][ds]=n;dv.innerHTML=183992;c[ac](dv);
            var s=iw[ce]('script');s.async='async';s.defer='defer';s.charset='utf-8';s.src="//jsc.mgid.com/f/i/filmyurl.com.183992.js?t="+D.getYear()+D.getMonth()+D.getDate()+D.getHours();c[ac](s);})();
    </script>
</div>
<!-- Go to www.addthis.com/dashboard to customize your tools -->
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5ab33a5e6a4d7c2e"></script>

</body>
</html>
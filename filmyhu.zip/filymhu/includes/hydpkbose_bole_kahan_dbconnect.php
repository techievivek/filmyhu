<?php
$dbservername="localhost";
$dbusername="u510580718_walaa";
$dbpassword="gIBDPZC30wMFBWON5H";
$dbname="u510580718_walaa";
$conn=mysqli_connect($dbservername,$dbusername,$dbpassword,$dbname);

<?php
include "includes/hydpkbose_bole_kahan_dbconnect.php";
include "header.php";
?>

<div class="container">
                    <div class="main-content">
                       
                        <div class="tab-content">
                            <div id="movie-featured" class="movies-list movies-list-full tab-pane in fade active">
<?php
if(isset($_GET['q']))
{
$string=$_GET['q'];
$string = stripslashes($string);
$string = strip_tags($string);
$query=mysqli_real_escape_string($conn,$string);
$sql="select * from movies where title like '%$query%' or content like '%$query%' or title like '%$query' or content like '%$query' or title='$query' or content='$query'";
$res=mysqli_query($conn,$sql);
if(mysqli_num_rows($res))
{
$que="insert into query(search) values('$query')";
mysqli_query($conn,$que);
	while($x6=mysqli_fetch_assoc($res))
	{
?>
                                    <div class="ml-item">
                                        <a href="post.php?id=<?php echo $x6['id']; ?>" title="<?php echo $x6['title']; ?>" class="ml-mask jt">
                                            <img src="<?php echo $x6['image']; ?>" alt="<?php echo $x6['title']; ?>" class="lazy thumb mli-thumb">
                                            <span class="mli-info">
                                                <h2 style="background-color:black; color:white">
                                                <?php echo $x6['title']; ?>
                                                </h2>
                                            </span>
                                        </a>
                                    </div>  
<?php
}
}
else
{  

$que1="insert into wrong_query(search) values('$query')";
mysqli_query($conn,$que1);
	?>
	<br><br><h2>No Results Found!!!!.....Please Try Again With <span style="color:red; text-decoration:underline">Correct Movie Name</span></h2>
	<?php
	
}
	
?>
                  </div>
                    </div>
                    </div>
                </div>
<?php

} 
else
{
	header("Location:https://filmyurl.com/index.php");
}

?>
<?php
include "header.php";
?>

<p style="margin-top:2%; margin-right:25%; margin-left:25%; color:blue; font-family:Times New Roman; font-size:32px; text-decoration:underline">Privacy Policy</p>
<div style="margin-left:25%; margin-right:25%; margin-top:5%; margin-bottom:5%; text-align:justify; font-size:23px; font-family:Times New Roman">
    <h2 style="display:inline">filmyhu</h2> is not the solitary owner of the multimedia published on this website. We work here as a community and collects all these multimedia files from various other websites, who have already posted it on their sites. But we maintain the privacy of our audience through various means of protection and do not share their personal information with any third party.  We have no intention to disrespect any gender, community or any tradition.  
All are welcome here to entertain themselves and give their valuable suggestions and expectations on our facebook page. We will contact you as fast as possible to encounter your query.
We don’t collect cookies for any personal use or to enhance the user experience, but yes! we do keep an eye on how to increase the user experience and make your experience on the site more efficient.This privacy policy is subject to change without notice and was last updated on <?php $x=getdate(); echo $x['month'].' '.$x['year'];?>. If you have any questions feel free to contact us directly here on our <a href="https://www.facebook.com/filmyhu/">facebook page</a> and drop a message.
</div>




<?php
include "footer.php";
?>
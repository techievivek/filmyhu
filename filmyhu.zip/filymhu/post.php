<?php
include "includes/hydpkbose_bole_kahan_dbconnect.php";
if(isset($_GET['id']))
{
$id=$_GET['id'];
$sql="select * from movies where id='$id'";
$res=mysqli_query($conn,$sql);
if(mysqli_num_rows($res)>0)
{
$x=mysqli_fetch_assoc($res);
$x['count']+=1;
$sql2= "UPDATE movies SET count={$x['count']} WHERE id={$x['id']}";
mysqli_query($conn,$sql2);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>FilmyWapHD.co download or watch online latest hindi movies,hindi dubbed movies,hollywood movies,south movies,Watch latest movies online,watch online <?php echo ucwords($x['title']); ?> full movie,watch online <?php echo ucwords($x['title']); ?> movie in hd,watch online <?php echo ucwords($x['category']); ?> latest movies free,Download <?php echo ucwords($x['title']); ?> full movie,<?php echo ucwords($x['title']); ?>  full movie download in HD,720p <?php echo ucwords($x['title']); ?> full movie download,300mb <?php echo ucwords($x['title']); ?>  full movie download,latest <?php echo ucwords($x['title']); ?>  movie download HD,latest <?php echo ucwords($x['category']); ?> movie download,2018 <?php echo ucwords($x['category']); ?> movie download,new <?php echo ucwords($x['category']); ?> movies download,<?php echo ucwords($x['title']); ?> movie download FilmyWapHD.co,FilmyWapHD.co <?php echo ucwords($x['title']); ?> full movie download,FilmyWapHD.co <?php echo ucwords($x['category']); ?> movie download,FilmyWapHD.co latest movie download,2018 FilmyWapHD.co movies</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" > 
<meta name="keywords" content="<?php echo ucwords($x['title']); ?> full movie download,<?php echo ucwords($x['title']); ?> movie download,<?php echo ucwords($x['title']); ?> movie download in hd,<?php echo ucwords($x['title']); ?> 300mb download,latest <?php echo ucwords($x['category']); ?> movies download,new <?php echo ucwords($x['category']); ?> movie download,2018 <?php echo ucwords($x['category']); ?> movie download" >
<meta name="description" content="<?php echo ucwords($x['title']); ?> movie free download,<?php echo ucwords($x['title']); ?> watch online,<?php echo ucwords($x['title']); ?> movie watch online in hd,<?php echo ucwords($x['title']); ?> in hd download,<?php echo ucwords($x['title']); ?> download in high quality,">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/main.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="css/contactstyle.css" type="text/css" media="all" />
<link rel="stylesheet" href="css/faqstyle.css" type="text/css" media="all" />
<link href="css/single.css" rel='stylesheet' type='text/css' />
<link href="css/medile.css" rel='stylesheet' type='text/css' />
<!-- banner-slider -->
<link href="css/jquery.slidey.min.css" rel="stylesheet">
<!-- //banner-slider -->
<!-- pop-up -->
<link href="css/popuo-box.css" rel="stylesheet" type="text/css" media="all" />
<!-- //pop-up -->
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font-awesome.min.css" />
<!-- //font-awesome icons -->
<!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- //js -->
<!-- banner-bottom-plugin -->
<link href="css/owl.carousel.css" rel="stylesheet" type="text/css" media="all">
<script src="js/owl.carousel.js"></script>
<script>
	$(document).ready(function() { 
		$("#owl-demo").owlCarousel({
	 
		  autoPlay: 3000, //Set AutoPlay to 3 seconds
	 
		  items : 5,
		  itemsDesktop : [640,4],
		  itemsDesktopSmall : [414,3]
	 
		});
	 
	}); 
</script> 
<!-- //banner-bottom-plugin -->
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700italic,700,400italic,300italic,300' rel='stylesheet' type='text/css'>
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>

<!-- start-smoth-scrolling -->

</head>
	
<body>
   <!-- header -->
	<div class="header">
		<div class="container">
			<div class="w3layouts_logo" >
				<a href="index.php"><h2>FilmyWapHD</h2></a>
			</div>
			<div class="w3_search">
				<form action="search.php" method="GET">
					<input type="text" name="q" placeholder="Search Movies">
					<input type="submit" value="search">
				</form>
			</div>
					<div class="clearfix"> </div>
		</div>
	</div>
<!-- //header -->
	<div class="movies_nav">
		<div class="container">
			<nav class="navbar navbar-default">
				<div class="navbar-header navbar-left">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
					<nav>
						<ul class="nav navbar-nav">
							<li class="active"><a href="https://FilmyWapHD.co">Home</a></li>
							<li><a href="https://www.FilmyWapHD.co/latest-movies.php">Latest Movies</a></li>
							<li><a href="https://www.FilmyWapHD.co/bollywood.php">Bollywood</a></li>
							<li><a href="https://www.FilmyWapHD.co/hollywood.php">Hollywood</a></li>
							<li><a href="https://www.FilmyWapHD.co/hindidubbed.php">Hindi Dubbed</a></li>
							<li><a href="https://www.FilmyWapHD.co/southmovies.php">South Movies</a></li>
							<li><a href="https://www.FilmyWapHD.co/privacy.php">Privacy Policy</a></li>
							</ul>	
					</nav>
				</div>
			</nav>	
		</div>
	</div>
<div class="single-page-agile-main">
<div class="container">
		<!-- /w3l-medile-movies-grids -->
			<div class="agileits-single-top">
				<ol class="breadcrumb">
				  <li><a href="index.php">Home</a></li>
				  <li class="active">Single</li>
				</ol>
			</div>
			<div class="single-page-agile-info">
                   <!-- /movie-browse-agile -->
                           <div class="show-top-grids-w3lagile">
				<div class="col-sm-8 single-left">
					<div class="song">
						<div class="song-info">
							<h1 style="font-family:Georgia, serif; color:white"><span style="background-color:#e26f0b"><?php echo ucfirst($x['title']); ?></span></h1>	
		
					    </div>
					<!-----------------------------------@@@@@@@@@@@@@@@@@@@@   Video  part----------------@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@----------->
						<div><video style="max-width: 100%; height: auto;" poster="<?php echo $x['poster']; ?>" controls autoPlay>
                              <source src="<?php echo $x['video']; ?>" type="video/mp4" >
                               Your browser does not support HTML5 video.
                              </video></div>
                             <h3 style="background-color:#ff8d30;margin-bottom:3px;">Sharing is Caring!!!</h3><!-- AddToAny BEGIN -->
<div style="margin-right:auto;margin-left:auto" class="a2a_kit a2a_kit_size_32 a2a_default_style">
<a class="a2a_dd" href="https://www.addtoany.com/share"></a>
<a class="a2a_button_facebook"></a>
<a class="a2a_button_whatsapp"></a>
<a class="a2a_button_sms"></a>
<a class="a2a_button_copy_link"></a>
<a class="a2a_button_facebook_messenger"></a>
<a class="a2a_button_twitter"></a>
<a class="a2a_button_google_plus"></a>
<a class="a2a_button_telegram"></a>
</div>
<script async src="https://static.addtoany.com/menu/page.js"></script>
<!-- AddToAny END -->
						<div >
						<h4 id="moviestyling"><?php echo ucwords($x['content']); ?>,Download <?php echo ucwords($x['title']); ?> movie free,latest movie <?php echo ucwords($x['title']); ?>download,<?php echo ucwords($x['category']); ?> movie <?php echo ucwords($x['title']); ?> download free,720p <?php echo ucwords($x['title']); ?> movie download,300 mb <?php echo ucwords($x['title']); ?> movie download,watch online latest movie <?php echo ucwords($x['title']); ?>,<?php echo ucwords($x['title']); ?> full movie HD download FilmyWapHD.co,FilmyWapHD.co <?php echo ucwords($x['title']); ?> movie download,500 mb <?php echo ucwords($x['title']); ?> full movie download,Download latest bollywood,hollywood,hindidubbed,south movies for free from FilmyWapHD.co,latest hindi movies download,latest bollywood movie download,latest hindi dubbed movie download,new movies download free,FilmyWapHD.co download or watch online latest hindi movies,hindi dubbed movies,hollywood movies,south movies,Watch latest movies online,watch online <?php echo ucwords($x['title']); ?> full movie,watch online <?php echo ucwords($x['title']); ?> movie in hd,watch online <?php echo ucwords($x['category']); ?> latest movies free,Download <?php echo ucwords($x['title']); ?> full movie,<?php echo ucwords($x['title']); ?>  full movie download in HD,720p <?php echo ucwords($x['title']); ?> full movie download,300mb <?php echo ucwords($x['title']); ?>  full movie download,latest <?php echo ucwords($x['title']); ?>  movie download HD,latest <?php echo ucwords($x['category']); ?> movie download,2018 <?php echo ucwords($x['category']); ?> movie download,new <?php echo ucwords($x['category']); ?> movies download,<?php echo ucwords($x['title']); ?> movie download FilmyWapHD.co,FilmyWapHD.co <?php echo ucwords($x['title']); ?> full movie download,FilmyWapHD.co <?php echo ucwords($x['category']); ?> movie download,FilmyWapHD.co latest movie download,2018 FilmyWapHD.co movies</h4><hr>
						  <h1 style="font-weight:bold; color:#428cf4; text-decoration:underline; font-family:serif"> Download Links</h1>
						 <h4 style="background-color:#f49542; width:100%; margin-top:3px; margin-bottom:3px;" >If Download Links Are Not working Then please Inform Us we will fix in Minutes</h4>
<?php
//if "email" variable is filled out, send email
  if (isset($_REQUEST['email']))  {
  
  //Email information
  $admin_email = "nizamuddinfytb@gmail.com";
  $email = $_REQUEST['email'];
  $subject = "Mail From Website FilmyWap Website";
  $comment = $_REQUEST['comment'];
  
  //send email
  $mail=mail($admin_email, "$subject", $comment, "From:" . $email);
  if($mail)
  echo "<h3>Thanks For Letting us know,It will be fixed in Minutes!!<h3>";
  else
  echo "Mail Not Sent....TRY AGAIN!!!<h3>";
  }
  
  //if "email" variable is not filled out, display the form
  else  {
?>
<form method="post">
    <fieldset>
        <input name="email" type="text" placeholder="Email" />
        <input type="text" placeholder="Movie Name" name="comment" />
		
        <input type="submit" value="Submit" class="pure-button pure-button-primary" style="background-color:#f49542;"/>
    </fieldset>
</form>
  
<?php
  }
?>
				<hr>	   <a href="<?php echo $x['download1']; ?>" download><img src="images/download.png" id="advertise" ></a>
											 <hr><a href="<?php echo $x['download1']; ?>" download><img src="images/download.png" id="advertise" ></a>
						 </div>
						 
					</div>
					<!----------------------------------------@@@@@@@@@@@@@@@@@@@@@@@@@@     video part finshed--------------------@@@@@@@@@@@@@@@@@-------------------->
							<!-----------------------In-article Widget------------>

					<div class="song-grid-right">
					
					</div>
					<div class="clearfix"> </div>
				</div>
				<!---------------------------###################### Advertisement---------------################------------------>
				<div class="col-md-4 single-right">
				 
					<h3>Advertisement</h3>
					<div class="single-grid-right">
						<div class="single-right-grids">
							<!-----------------------Sidebar widget-------------->

							<div class="clearfix"> </div>
						</div>
						<div class="single-right-grids">
							
							<div class="clearfix"> </div>
						</div>
						<div class="single-right-grids">
							
							<div class="clearfix"> </div>
						</div>
						<div class="single-right-grids">
							
							<div class="clearfix"> </div>
						</div>
						<div class="single-right-grids">
							
							<div class="clearfix"> </div>
						</div>
						<div class="single-right-grids">
							
							<div class="clearfix"> </div>
						</div>
						<div class="single-right-grids">
							
							<div class="clearfix"> </div>
						</div>
						<div class="single-right-grids">
							
							<div class="clearfix"> </div>
						</div>

					</div>
				</div>
				
				<!---------------------------###################### Advertisement finshed---------------################------------------>

				
				<div class="clearfix"> </div>
			</div>
			<h4  style="background-color:#ff9123; font-size:30px; text-align:center">Other Movies To Watch</h4>
				<!-- //movie-browse-agile -->
				<!--body wrapper start-->
			<div class="w3_agile_banner_bottom_grid">
				<div id="owl-demo" class="owl-carousel owl-theme">
					
					<?php
					$result_per_page=8;
					$sql2="select * from movies LIMIT ".$id.','.$result_per_page;
					$res2=mysqli_query($conn,$sql2);
					if(mysqli_num_rows($res2))
					{
						while($x1=mysqli_fetch_assoc($res2))
						{
					?>
					<div class="item">
						<div class="w3l-movie-gride-agile w3l-movie-gride-agile1">
							<a href="post.php?id=<?php echo $x1['id'];?>" class="hvr-shutter-out-horizontal"><img id="moviebox" src="<?php echo $x1['image'];?>" title="album-name" class="img-responsive" alt="<?php echo $x1['title'];?>" />
								<div class="w3l-action-icon"><i class="fa fa-play-circle" aria-hidden="true"></i></div>
							</a>
							<div class="mid-1 agileits_w3layouts_mid_1_home">
								<div class="w3l-movie-text">
									<h6><a href="post.php?id=<?php echo $x1['id'];?>"><?php echo $x1['title'];?></a></h6>							
								</div>
								
							</div>
							<?php
							if($x1['year']>2017)
							{
								?>
							<div class="ribben">
								<p>NEW</p>
							</div>
							<?php
							}
							else
							{
								?>
								<div class="ribben">
								<p>OLD</p>
							</div>
							<?php
							}
							?>
						</div>
					</div>
					<?php
						}
					}
					?>
					
					
				</div>
			</div>
		<!--body wrapper end-->
						
							 
				</div>
				<!-- //w3l-latest-movies-grids -->
			</div>	
		</div>
	<!-- //w3l-medile-movies-grids -->
	
<?php
include "footer.php";
?>
<?php
}
else
{
	header("Location:index.php");
}
}
else
{
	header("Location:index.php");
}

?>

<?php
include "header.php";
include "includes/hydpkbose_bole_kahan_dbconnect.php";
$y1=getdate();
$sql1="select * from upcomin_movies  order by id DESC LIMIT 8";
$sql2="select * from movies WHERE year=".$y1['year']." order by id DESC LIMIT  10";
$sql3="SELECT * FROM movies WHERE category='hollywood' order by id DESC LIMIT 8";
$sql4="SELECT * FROM movies WHERE category='bollywood' order by id DESC LIMIT 8";
$sql5="SELECT * FROM movies WHERE category='hindi dubbed' order by id DESC LIMIT 8";
$sql6="SELECT * FROM movies WHERE category='south' order by id DESC LIMIT 8";
$sql7="SELECT * FROM movies where category='bollywood' or category='hindi dubbed' ORDER BY count DESC LIMIT 8";
?>
	<!----------------------------------------End of Header------------------------------------------------------------------>
<br>
		<h4 class="latest-text w3_latest_text">UPCOMING MOVIES</h4>
	<div id="slidey" style="display:none;">
		<ul>
		<?php
		$res1=mysqli_query($conn,$sql1);
		if(mysqli_num_rows($res1)>0)
		{
			while($x1=mysqli_fetch_assoc($res1))
			{
		?>
		    <li><img src="<?php echo $x1['image'];?>" alt="<?php echo $x1['title'];?> "><p class='title'><?php echo $x1['title'];?></p><p class='description'><?php echo $x1['content'];?></p></li>
		<?php
			}
		}
		?>
		</ul>   	
    </div>
    <script src="js/jquery.slidey.js"></script>
    <script src="js/jquery.dotdotdot.min.js"></script>
	   <script type="text/javascript">
			$("#slidey").slidey({
				interval: 8000,
				listCount: 5,
				autoplay: false,
				showList: true
			});
			$(".slidey-list-description").dotdotdot();
		</script>
<!-- //banner -->
<!-- banner-bottom -->
	<div class="banner-bottom">
	<h4 class="latest-text w3_latest_text">LATEST MOVIES</h4>
		<div class="container">
			<div class="w3_agile_banner_bottom_grid">
				<div id="owl-demo" class="owl-carousel owl-theme">
				<!------------------------New Movies List----------------------->
				<?php
				  $res2=mysqli_query($conn,$sql2);
		          if(mysqli_num_rows($res2)>0)
		          {
			       while($x2=mysqli_fetch_assoc($res2))
			      {
		        ?>
			        <div class="item">
					    <div class="w3l-movie-gride-agile w3l-movie-gride-agile1">
							<a href="post.php?id=<?php echo $x2['id']; ?>" class="hvr-shutter-out-horizontal"><img id="moviebox" src="<?php echo $x2['image']; ?>" title="album-name" class="img-responsive" alt="<?php echo $x2['title']; ?>" />
						    <div class="w3l-action-icon"><i class="fa fa-play-circle" aria-hidden="true"></i></div>
							</a>
							<div class="mid-1 agileits_w3layouts_mid_1_home">
								<div class="w3l-movie-text">
									<h6><a href="post.php?id=<?php echo $x2['id']; ?>"><?php echo $x2['title']; ?></a></h6>							
								</div>
								
							</div>
							<?php
							$y=getdate();
							if($x2['year']>=$y['year'])
							{
								?>
							<div class="ribben">
								<p>NEW</p>
							</div>
							<?php
							}
							else
							{
								?>
								<div class="ribben">
								<p>OLD</p>
							</div>
							<?php
							}
							?>
						</div>
					</div>
					<?php
				   }
				  }
				  ?>
					
				</div>
			</div>			
		</div>
	</div>
<!-- //banner-bottom -->
<div class="general_social_icons">
	<nav class="social">
  </nav>
</div>



<h4 class="latest-text w3_latest_text">Most Popular Movies</h4>
	<div class="container">
<div class="main-content">
<div class="tab-content">
<div id="movie-featured" class="movies-list movies-list-full tab-pane in fade active">

                                    <?php
									  $res7=mysqli_query($conn,$sql7);
									  if(mysqli_num_rows($res7)>0)
									  {
									   while($x7=mysqli_fetch_assoc($res7))
									  {
		                              ?>
                                        <div class="ml-item">
                                        <a href="post.php?id=<?php echo $x7['id']; ?>" title="<?php echo $x7['title']; ?>" class="ml-mask jt">
                                            <img src="<?php echo $x7['image']; ?>" alt="<?php echo $x7['title']; ?>" class="lazy thumb mli-thumb" id="moviebox" class="img-responsive">
                                            <span class="mli-info">
                                                <h2 style="background-color:black; color:white">
                                              <?php echo $x7['title']; ?>
                                                </h2>
                                            </span>
                                        </a>
                                    </div>
                                   <?php
									  }
									  }
									  ?>
                                </div>
</div>
</div>
</div>






<!-- general -->
<h4 class="latest-text w3_latest_text">Hollywood Movies<a href="hollywood.php" target="self"><img class="viewmore" src="images/view more.png" style="float:right;"></a></h4>
	<div class="container">
<div class="main-content">
<div class="tab-content">
<div id="movie-featured" class="movies-list movies-list-full tab-pane in fade active">

                                    <?php
									  $res3=mysqli_query($conn,$sql3);
									  if(mysqli_num_rows($res3)>0)
									  {
									   while($x3=mysqli_fetch_assoc($res3))
									  {
		                              ?>
                                        <div class="ml-item">
                                        <a href="post.php?id=<?php echo $x3['id']; ?>" title="<?php echo $x3['title']; ?>" class="ml-mask jt">
                                            <img src="<?php echo $x3['image']; ?>" alt="<?php echo $x3['title']; ?>" class="lazy thumb mli-thumb" id="moviebox" class="img-responsive">
                                            <span class="mli-info">
                                                <h2 style="background-color:black; color:white">
                                              <?php echo $x3['title']; ?>
                                                </h2>
                                            </span>
                                        </a>
                                    </div>
                                   <?php
									  }
									  }
									  ?>
                                </div>
</div>
</div>
</div>

<!-------------------------------------------Bollywood -------------------------------------------------->
<h4 class="latest-text w3_latest_text">Bollywood Movies<a href="bollywood.php" target="self"><img class="viewmore" src="images/view more.png" style="float:right"></a></h4>
	<div class="container">
<div class="main-content">
<div class="tab-content">
<div id="movie-featured" class="movies-list movies-list-full tab-pane in fade active">
 		                          <?php
									  $res4=mysqli_query($conn,$sql4);
									  if(mysqli_num_rows($res4)>0)
									  {
									   while($x4=mysqli_fetch_assoc($res4))
									  {
		                              ?>
 		                        <div class="ml-item">
									
                                        <a href="post.php?id=<?php echo $x4['id']; ?>" title="<?php echo $x4['title']; ?>" class="ml-mask jt">
                                            <img src="<?php echo $x4['image']; ?>" alt="<?php echo $x4['title']; ?>" class="lazy thumb mli-thumb" id="moviebox" class="img-responsive">
                                            <span class="mli-info">
                                                <h2 style="background-color:black; color:white">
                                                 <?php echo $x4['title']; ?>
                                                </h2>
                                            </span>
                                        </a>
                                </div>
								<?php
									  }
									  }
									  ?>
                                    
                                  
</div>
</div>
</div>
</div>

<!------------------------------------------Hindi Dubbed Movies----------------------------------------->
<h4 class="latest-text w3_latest_text">Hindi Dubbed Movies<a href="hindidubbed.php" target="self"><img class="viewmore" src="images/view more.png" style="float:right"></a></h4>
	<div class="container">
<div class="main-content">
<div class="tab-content">
<div id="movie-featured" class="movies-list movies-list-full tab-pane in fade active">
                                     <?php
									  $res5=mysqli_query($conn,$sql5);
									  if(mysqli_num_rows($res5)>0)
									  {
									   while($x5=mysqli_fetch_assoc($res5))
									  {
		                              ?>
                                    <div class="ml-item">
                                        <a href="post.php?id=<?php echo $x5['id']; ?>" title="<?php echo $x5['title']; ?>" class="ml-mask jt">
                                            <img src="<?php echo $x5['image']; ?>" alt="<?php echo $x5['title']; ?>" class="lazy thumb mli-thumb" id="moviebox" class="img-responsive">
                                            <span class="mli-info">
                                                <h2 style="background-color:black; color:white">
                                                <?php echo $x5['title']; ?>
                                                </h2>
                                            </span>
                                        </a>
                                    </div>    
									<?php
									}
									}
									?>
                                               
</div>
</div>
</div>
</div>

<!------------------------South Movies------------------------------------------------------------------->
<div><h4 class="latest-text w3_latest_text">South Movies<a href="southmovies.php" target="self"><img class="viewmore" src="images/view more.png" style="float:right"></a></h4></div>
	<div class="container">
<div class="main-content">
<div class="tab-content">
<div id="movie-featured" class="movies-list movies-list-full tab-pane in fade active">
                                            <?php
									  $res6=mysqli_query($conn,$sql6);
									  if(mysqli_num_rows($res6)>0)
									  {
									   while($x6=mysqli_fetch_assoc($res6))
									  {
		                              ?>
                                    <div class="ml-item">
                                        <a href="post.php?id=<?php echo $x6['id']; ?>" title="<?php echo $x6['title']; ?>" class="ml-mask jt">
                                            <img src="<?php echo $x6['image']; ?>" alt="<?php echo $x6['title']; ?>" class="lazy thumb mli-thumb" id="moviebox" class="img-responsive">
                                            <span class="mli-info">
                                                <h2 style="background-color:black; color:white">
                                                <?php echo $x6['title']; ?>
                                                </h2>
                                            </span>
                                        </a>
                                    </div>    
									<?php
									}
									}
									?>					  
</div>
</div>
</div>
</div>

<?php
include "footer.php";
?>
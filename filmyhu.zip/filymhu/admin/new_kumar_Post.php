<meta name="robots" content="noindex,nofollow">
<?php
session_start();
if(isset($_SESSION['username']))
{
?>
<h1 style="text-align:center; background-color:skyblue">Filmyhu-World's Biggest Movie Website</h1>
<h1 style="text-align:center; background-color:yellow">Welcome Admin</h1>
<table border="5" style="width:100%; text-align:center" >
<tr>
<td style="background-color:#68ffbb"><a href="ARIT_index.php" >Home</a>
</td>
<td style="background-color:#68ffbb"><a href="new_kumar_Post.php" target="_blank">Add New Post</a>
</td>
<td style="background-color:#68ffbb"><a href="tera_upcoming_movies_chahiye.php" target="_blank">Upcoming Movies</a>
</td>
<td style="background-color:#68ffbb"><a href="view_dekhega_analytics_wala.php" target="_blank">Analytics</a>
</td>
<td style="background-color:#68ffbb"><a href="vivek_logout_hawakhana_hyd.php" target="_blank">Logout</a>
</td>
</tr>
</table>
<h1 style="text-align:center; background-color:#5effff; text-decoration:underline">INSERT NEW MOVIE DATA</h1>
	
	<form action="post_hawa_bihar_khana_checking.php" enctype="multipart/form-data" method="POST">
	<table border="5" style="width:80%; height:80%; margin:auto" cellspacing="7px" >
	<tr>
	<td style="background-color:#c9ffcb">Title</td>
	<td style="background-color:#ffd9ce"><input type="text" name="title"></td>
	</tr>
	
	<tr>
	<td style="background-color:#c9ffcb">Content</td>
	<td style="background-color:#ffd9ce"><textarea name="content" type="text" rows="10" cols="60"></textarea></td>
	</tr>
	
	<tr>
	<td style="background-color:#c9ffcb">Release Year</td>
	<td style="background-color:#ffd9ce"><input type="number" name="year"></td>
	</tr>
	 
	 <tr>
	<td style="background-color:#c9ffcb">Category</td>
	<td style="background-color:#ffd9ce"><input type="text" name="category"></td>
	</tr>

	<tr>
	<td style="background-color:#c9ffcb">Video Url</td>
	<td style="background-color:#ffd9ce"><input type="text" name="video"></td>
	</tr>
	
	<tr>
	<td style="background-color:#c9ffcb">Download Link 1</td>
	<td style="background-color:#ffd9ce"><input type="text" name="download1"></td>
	</tr>
	
	<tr>
	<td style="background-color:#c9ffcb">Download Link 2</td>
	<td style="background-color:#ffd9ce"><input type="text" name="download2"></td>
	</tr>
	
	<tr>
	<td style="background-color:#c9ffcb">Main Image</td>
	<td style="background-color:#ffd9ce"><input type="text" name="image"></td>
	</tr>
	
	 
	<tr>
	<td style="background-color:#c9ffcb">Poster Image</td>
	<td style="background-color:#ffd9ce"><input type="text" name="poster"></td>
	</tr>
	<tr >
	<td colspan="2" style="text-align:center; vertical-align:center; background-color:#ff8787"> <input type="submit" name="submit" value="UPLOAD"></td>
	</tr>
	</table>
	</form>
<?php
}
else
	header("Location:hawa_hawai_login.php");
?>


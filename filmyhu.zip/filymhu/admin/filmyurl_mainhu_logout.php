<meta name="robots" content="noindex,nofollow">
<?php
include "../includes/hydpkbose_bole_kahan_dbconnect.php";
session_start();
if(!isset($_SESSION['username']))
{
	header("Location:hawa_hawai_login.php");
}
else
{
	
	header("Location:hawa_hawai_login.php?logout=true");
	session_destroy();
	
	
}
?>
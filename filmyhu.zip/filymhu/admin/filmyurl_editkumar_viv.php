<meta name="robots" content="noindex,nofollow">
<?php
include "../includes/hydpkbose_bole_kahan_dbconnect.php";
session_start();
if(!isset($_SESSION['username']))
{
	header("Location:hawa_hawai_login.php");
}
else
{ 
    $id=$_GET['id'];
	$sql="select * from movies where id='$id'";
	$res=mysqli_query($conn,$sql);
	$rows=mysqli_num_rows($res);
	if($rows>0)
	{
		while($x=mysqli_fetch_assoc($res))
		{
			?>
			<h1 style="text-align:center; background-color:skyblue">FilmyUrl-World's Biggest Movie Website</h1>
<h1 style="text-align:center; background-color:yellow">Welcome Admin</h1>
<table border="5" style="width:100%; text-align:center" >
<tr>
<td style="background-color:#68ffbb"><a href="ARIT_index.php" >Home</a>
</td>
<td style="background-color:#68ffbb"><a href="new_kumar_Post.php" target="_blank">Add New Post</a>
</td>
<td style="background-color:#68ffbb"><a href="upcoming_movies_chahiye.php" target="_blank">Upcoming Movies</a>
</td>
<td style="background-color:#68ffbb"><a href="analytics_wala.php" target="_blank">Analytics</a>
</td>
<td style="background-color:#68ffbb"><a href="filmyurl_mainhu_logout.php" target="_blank">Logout</a>
</td>
</tr>
</table>
	<form action="filmyurl_editkumar_viv.php?edit_post=<?php echo $x['id'] ?>" enctype="multipart/form-data" method="POST">
	<table border="5" style="width:80%; height:80%; margin:auto" cellspacing="7px" >
	<tr>
	<td style="background-color:#c9ffcb">Title</td>
	<td style="background-color:#ffd9ce"><input type="text" name="title" value="<?php echo $x['title']; ?>"></td>
	</tr>
	
	<tr>
	<td style="background-color:#c9ffcb">Content</td>
	<td style="background-color:#ffd9ce"><textarea name="content" type="text" rows="10" cols="60" ><?php echo $x['content']; ?></textarea></td>
	</tr>

	
	<tr>
	<td style="background-color:#c9ffcb">Release Year</td>
	<td style="background-color:#ffd9ce"><input type="number" name="year" value="<?php echo $x['year']; ?>"></td>
	</tr>
	 
	 <tr>
	<td style="background-color:#c9ffcb">Category</td>
	<td style="background-color:#ffd9ce"><input type="text" name="category" value="<?php echo $x['category']; ?>"></td>
	</tr>

	<tr>
	<td style="background-color:#c9ffcb">Video Url</td>
	<td style="background-color:#ffd9ce"><input type="text" name="video" value="<?php echo $x['video']; ?>"></td>
	</tr>
	
	<tr>
	<td style="background-color:#c9ffcb">Download Link 1</td>
	<td style="background-color:#ffd9ce"><input type="text" name="download1" value="<?php echo $x['download1']; ?>"></td>
	</tr>
	
	<tr>
	<td style="background-color:#c9ffcb">Download Link 2</td>
	<td style="background-color:#ffd9ce"><input type="text" name="download2" value="<?php echo $x['download2']; ?>"></td>
	</tr>
	
	<tr>
	<td style="background-color:#c9ffcb">Main Image</td>
	<td style="background-color:#ffd9ce"><input type="text" name="image" value="<?php echo $x['image']; ?>"></td>
	</tr>
	
	
	<tr>
	<td style="background-color:#c9ffcb">Poster Image</td>
	<td style="background-color:#ffd9ce"><input type="text" name="poster" value="<?php echo $x['poster']; ?>"></td>
	</tr>
	
	<tr >
	<td colspan="2" style="text-align:center; vertical-align:center; background-color:#ff8787"> <input type="submit" name="submit" value="UPLOAD"></td>
	</tr>
	</table>
	</form>
			
	<?php
	
		}
	}
if(isset($_POST['submit']))
{ $id1=isset($_GET['edit_post']) ? $_GET['edit_post'] : '';
$title=mysqli_real_escape_string($conn,$_POST['title']);
$content=mysqli_real_escape_string($conn,$_POST['content']);
$year=mysqli_real_escape_string($conn,$_POST['year']);
$category=mysqli_real_escape_string($conn,$_POST['category']);
$video=mysqli_real_escape_string($conn,$_POST['video']);
$download1=mysqli_real_escape_string($conn,$_POST['download1']);
$download2=mysqli_real_escape_string($conn,$_POST['download2']);
$image=mysqli_real_escape_string($conn,$_POST['image']);
$poster=mysqli_real_escape_string($conn,$_POST['poster']);
if($title=='' || $content==''|| $year=='' || $category=='' || $download1==''|| $download2=='' || $video=='')
{
	echo "<script type='text/javascript'>alert('Fill All The The Fields');</script>";
	exit();
}
else 
{
		$sql="update movies set title='$title',content='$content',year='$year',category='$category',video='$video',download1='$download1',download2='$download2',image='$image',poster='$poster' where id= '$id1'";
		if(mysqli_query($conn,$sql))
		{
		header("Location:ARIT_index.php?edit=success");
		}
		else
		{
			echo "<script type='text/javascript'>alert('Maybe You would Have Used Illegal Characters');</script>";
		}
	
	
}

	
}




?>	
			
			
			
			
			
			
			
			
			
			
			
			
			
<?php
}
?>
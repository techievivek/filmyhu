<meta name="robots" content="noindex,nofollow">
<?php
include "../includes/hydpkbose_bole_kahan_dbconnect.php";
session_start();
if(!isset($_SESSION['username']))
{
	header("Location:hawa_hawai_login.php");
}
else
{
?>
<h1 style="text-align:center; background-color:skyblue">Filmyhu-World's Biggest Movie Website</h1>
<h1 style="text-align:center; background-color:#5effff; text-decoration:underline">INSERT UPCOMING MOVIE DATA</h1>
	
	<form action="upcoming_movies_chahiye.php" enctype="multipart/form-data" method="POST">
	<table border="5" style="width:80%; height:80%; margin:auto" cellspacing="7px" >
	<tr>
	<td style="background-color:#c9ffcb">Title</td>
	<td style="background-color:#ffd9ce"><input type="text" name="title"></td>
	</tr>
	
	<tr>
	<td style="background-color:#c9ffcb">Content</td>
	<td style="background-color:#ffd9ce"><textarea name="content" type="text" rows="10" cols="60"></textarea></td>
	</tr>
 <tr>
	<td style="background-color:#c9ffcb">Main Image</td>
	<td style="background-color:#ffd9ce"><input type="text" name="image"></td>
	</tr>
	
	<tr>
	<td style="background-color:#c9ffcb">Youtube Link</td>
	<td style="background-color:#ffd9ce"><input type="text" name="youtube_link"></td>
	</tr>

	
	
	<tr >
	<td colspan="2" style="text-align:center; vertical-align:center; background-color:#ff8787"> <input type="submit" name="submit" value="UPLOAD"></td>
	</tr>
	</table>
	</form>
<?php
}
if(isset($_POST['submit']))
{
$title=mysqli_real_escape_string($conn,$_POST['title']);
$content=mysqli_real_escape_string($conn,$_POST['content']);
$youtube_link=mysqli_real_escape_string($conn,$_POST['youtube_link']);
$image=mysqli_real_escape_string($conn,$_POST['image']);
	
	
	if($title=='' || $content==''||  $youtube_link=='' || $image=='')
{
	echo "<script type='text/javascript'>alert('Fill All The The Fields');</script>";
	exit();
}
else 
{

		$sql="insert into upcomin_movies(title,content,image,youtube_link) values('$title','$content','$image','$youtube_link');";
		if(mysqli_query($conn,$sql))
		{
		header("Location:upcoming_movies_chahiye.php?post=success");
		
		}
		else
		{
			echo "<script type='text/javascript'>alert('Maybe You would Have Used Illegal Characters');</script>";
		}
		
	
}
	
	
	
}
?>
<meta name="robots" content="noindex,nofollow">
<h1 style="text-align:center; background-color:skyblue; margin-top:2%">Login Here</h1>
<form action="hawa_hawai_login.php" method="POST">
<table border="5" style="margin:auto" height="100px" width="200px">

<tr>
<td style="background-color:#dbceef">Username:
</td>
<td style="background-color:#ffb5c7"><input type="text" name="username" >
</td>
</tr>


<tr>
<td style="background-color:#dbceef">Password:
</td>
<td style="background-color:#ffb5c7"><input type="password" name="password" >
</td>
</tr>

<tr>
<td colspan="2" style="text-align:center; background-color:#ff8b5e"><input type="submit" name="submit" value="Login">
</td>
</tr>


</table>
</form> 
<?php
include_once "../includes/hydpkbose_bole_kahan_dbconnect.php";
session_start();
if(isset($_POST['submit']))
{
$user=mysqli_real_escape_string($conn,$_POST['username']);
$pass=mysqli_real_escape_string($conn,$_POST['password']);
echo $user;
echo $pass;
		
		if($user=='' || $pass=='')
			echo "<script type='text/javascript'>alert('First Fill Both Fields');</script>";
	    else
		{  
			$sql="select * from users where user='$user' and password='$pass'";
			$res=mysqli_query($conn,$sql);
			$rows=mysqli_num_rows($res);
			if($rows>0)
			{
				$_SESSION['username']='$user';
				header("Location:ARIT_index.php");
			}
		 else
			{
			echo "<script type='text/javascript'>alert('please Login Again');</script>";
			header("Location:hawa_hawai_login.php?=login=false");
			}
		}
		
		
	}



?>


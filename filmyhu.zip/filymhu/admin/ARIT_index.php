<meta name="robots" content="noindex,nofollow">
<?php
include "../includes/hydpkbose_bole_kahan_dbconnect.php";
session_start();
if(!isset($_SESSION['username']))
{
	header("Location:hawa_hawai_login.php");
}
else
{
?>

<h1 style="text-align:center; background-color:skyblue">Filmyhu-World's Biggest Movie Website</h1>
<h1 style="text-align:center; background-color:yellow">Welcome Admin</h1>
<table border="5" style="width:100%; text-align:center" >

<tr>
<td style="background-color:#68ffbb"><a href="ARIT_index.php">Home</a>
</td>
<td style="background-color:#68ffbb"><a href="new_kumar_Post.php" target="_blank">Add New Post</a>
</td>
<td style="background-color:#68ffbb"><a href="upcoming_movies_chahiye.php" target="_blank">Upcoming Movies</a>
</td>
<td style="background-color:#42f4a7"><form action="hallabol_maaki_paaki_search.php" method="GET"><input type="text" name="search" placeholder="Search Songs"><input type="submit" name="submit" value="Search"></form></td>
<td style="background-color:#68ffbb"><a href="analytics_wala.php" target="_blank">Analytics</a>
</td>
<td style="background-color:#68ffbb"><a href="filmyurl_mainhu_logout.php" target="_blank">Logout</a>
</td>
</tr>
</table>

<?php
$sql="select * from movies order by id DESC";
$res=mysqli_query($conn,$sql);
$row=mysqli_num_rows($res);
$result_per_page=10;
if(!isset($_GET['page']))
{
	$page=1;
	
}
else
{
	$page=$_GET['page'];
	
}

$this_page_first=($page-1)*$result_per_page;
$no_of_pages=ceil($row/$result_per_page);
$sqlite="select * from movies LIMIT ".$this_page_first.','.$result_per_page;
$result=mysqli_query($conn,$sqlite);
$rows=mysqli_num_rows($result);
if($rows>0)
{
?>
<table border="5" style="width:100%; text-align:center">
<tr>
<th>S.NO</th>
<th>Title</th>
<th>Release Year</th>
<th>Video Url</th>
<th>Image</th>
<th>Link1</th>
<th>Category</th>
<th>Views</th>
<th>Edit</th>
</tr>
<tr>
<?Php
while($x=mysqli_fetch_assoc($result))
{
?>
<td><?php echo $x['id']; ?></td>
<td><?php echo $x['title']; ?></td>
<td><?php echo $x['year']; ?></td>
<td><?php echo $x['video']; ?></td>
<td><img style="width:50px; height:50px" src="<?php echo $x['image']; ?>"</td>
<td><?php echo $x['download1']; ?></td>
<td><?php echo $x['category']; ?></td>
<td><?php echo $x['count']; ?></td>
<td><a href="filmyurl_editkumar_viv.php?id=<?php echo $x['id']; ?>">Edit</a></td>
</tr>
<?php
}	
}
?>

<table border="2" style="width:100%">
<tr>
<?php
for($page=1;$page<=$no_of_pages;$page++)
{
?>
<td><?php echo '<a href="ARIT_index.php?page='.$page.'">'.$page.'</a>'; ?></td>
<?php
}
?>
</tr>
</table>
<?php
?>

	
<?php	
}

?>

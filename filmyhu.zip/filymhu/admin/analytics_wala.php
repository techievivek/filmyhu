<meta name="robots" content="noindex,nofollow">
<?php
include "../includes/hydpkbose_bole_kahan_dbconnect.php";
session_start();
if(!isset($_SESSION['username']))
{
	header("Location:hawa_hawai_login.php");
}
else
{
$sql="select * from movies ORDER BY count DESC LIMIT 10";
$res=mysqli_query($conn,$sql);
?>
<h1 style="text-align:center; background-color:skyblue">Filmyhu-World's Biggest Movie Website</h1>
<h1 style="text-align:center; background-color:yellow">Welcome Admin</h1>
<table border="5" style="width:100%; text-align:center" >
<tr>
<td style="background-color:#ffa363"><a href="ARIT_index.php">Home</a>
</td>
<td style="background-color:#ffa363"><a href="new_kumar_Post.php" target="_blank">Add New Post</a>
</td>
<td style="background-color:#ffa363"><a href="upcoming_movies_chahiye.php" target="_blank">Upcoming Movies</a>
</td>
<td style="background-color:#ffa363"><a href="analytics_wala.php" target="_blank">Analytics</a>
</td>
<td style="background-color:#ffa363"><a href="filmyurl_mainhu_logout.php" target="_blank">Logout</a>
</td>
</tr>
</table>
<?php
if(mysqli_num_rows($res))
{
	?>
		<h2 style="text-decoration:underline">Statistic of Views</h2>
		<table border="5" style="width:100%; text-align:center">
		<tr>
		<th style="background-color:#68ffbb">ID.No</th>
		<th style="background-color:#68ffbb">Movie Name</th>
		<th style="background-color:#68ffbb">Views</th>
		</tr>
	<?php
	while($x=mysqli_fetch_assoc($res))
	{
		?>
	     <tr>
		 <td><?php echo $x['id']; ?></td>
		 <td><?php echo $x['title']; ?></td>
		 <td><?php echo $x['count']; ?></td>
		</tr>
	
<?php		
	}
	?>
		
		</table>
		<?php
}
?>
<h2 style="text-decoration:underline">Statistic of Wrong Search</h2>
<?php
$wrong="select * from wrong_query ORDER BY id DESC LIMIT 10";
$res1=mysqli_query($conn,$wrong);
if(mysqli_num_rows($res1))
{
	?>
		<table border="5" style="width:100%; text-align:center">
		<tr>
		<th style="background-color:#7faaff">ID.No</th>
		<th style="background-color:#7faaff">Query Name</th>
		</tr>
	<?php
	while($y=mysqli_fetch_assoc($res1))
	{
		?>
	     <tr>
		 <td><?php echo $y['id']; ?></td>
		 <td><?php echo $y['search']; ?></td>
		</tr>
	
<?php		
	}
	?>
		
		</table>
		<?php
}
?>

<h2 style="text-decoration:underline">Statistic of Correct Search</h2>
<?php
$correct="select * from query ORDER BY id DESC LIMIT 10";
$res2=mysqli_query($conn,$correct);
if(mysqli_num_rows($res2))
{
	?>
		<table border="5" style="width:100%; text-align:center">
		<tr>
		<th style="background-color:#eea3ff">ID.No</th>
		<th style="background-color:#eea3ff">Query Name</th>
		</tr>
	<?php
	while($z=mysqli_fetch_assoc($res2))
	{
		?>
	     <tr>
		 <td><?php echo $z['id']; ?></td>
		 <td><?php echo $z['search']; ?></td>
		</tr>
	
<?php		
	}
	?>
		
		</table>
		<?php
}
}
?>
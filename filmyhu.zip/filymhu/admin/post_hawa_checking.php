<meta name="robots" content="noindex,nofollow">
<?php
include_once "../includes/hydpkbose_bole_kahan_dbconnect.php";
session_start();
if(isset($_POST['submit']) and isset($_SESSION['username']))
{
$title=mysqli_real_escape_string($conn,$_POST['title']);
$content=mysqli_real_escape_string($conn,$_POST['content']);
$year=mysqli_real_escape_string($conn,$_POST['year']);
$category=mysqli_real_escape_string($conn,$_POST['category']);
$video=mysqli_real_escape_string($conn,$_POST['video']);
$download1=mysqli_real_escape_string($conn,$_POST['download1']);
$download2=mysqli_real_escape_string($conn,$_POST['download2']);
$image=mysqli_real_escape_string($conn,$_POST['image']);
$poster=mysqli_real_escape_string($conn,$_POST['poster']);

if($title=='' || $content==''|| $year=='' || $category=='' || $download1==''|| $download2=='' || $video=='')
{
	echo "<script type='text/javascript'>alert('Fill All The The Fields');</script>";
	exit();
}
else 
{
		$sql="insert into movies(title,content,year,category,video,download1,download2,image,poster) values('$title','$content','$year','$category','$video','$download1','$download2','$image','$poster');";
		if(mysqli_query($conn,$sql))
		{
		header("Location:new_kumar_Post.php?post=success");
		
		}
		else
		{
			echo "<script type='text/javascript'>alert('Maybe You would Have Used Illegal Characters');</script>";
		}

	
	
}


}
else
{
	header("Location:hawa_hawai_login.php");
}
?>